import { TestBed } from '@angular/core/testing';

import { PreloadScriptResolver } from './script-loader.service';

describe('PreloadScriptResolver', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PreloadScriptResolver = TestBed.get(PreloadScriptResolver);
    expect(service).toBeTruthy();
  });
});
